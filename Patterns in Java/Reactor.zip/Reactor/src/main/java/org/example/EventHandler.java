package org.example;

public interface EventHandler {
    void HandleEvent(Event e);
}
