package org.example;

public class ConcreteEventHandlerB implements EventHandler{
    public void HandleEvent(Event e)
    {
        System.out.println("ConcreteEventHandlerB handles event of type:" + e.type);
    }
}
