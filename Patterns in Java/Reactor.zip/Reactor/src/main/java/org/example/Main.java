package org.example;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Reactor reactor = new Reactor();

        reactor.registerHandler("EventA", new ConcreteEventHandlerA());
        reactor.registerHandler("EventB", new ConcreteEventHandlerB());


        ArrayList<Event> events = new ArrayList<Event>();
        events.add(new Event("EventA"));
        events.add( new Event("EventB"));
        events.add( new Event("EventC"));

        reactor.handleEvents(events);
    }
}