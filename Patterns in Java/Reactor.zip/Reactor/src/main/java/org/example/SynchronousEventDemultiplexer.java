package org.example;

public class SynchronousEventDemultiplexer {
    public void handle(Event e) {
        // logic
        System.out.println("Demultiplexer handles event of type: " + e.type);
    }

}
