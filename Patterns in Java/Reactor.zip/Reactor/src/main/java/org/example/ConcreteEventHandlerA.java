package org.example;

public class ConcreteEventHandlerA implements EventHandler{
    public void HandleEvent(Event e)
    {
        System.out.println("ConcreteEventHandlerA handles event of type:" + e.type);
    }
}
