package org.example;

public class Event {

    public String type;

    public Event(String type)
    {
        this.type = type;
    }
}
