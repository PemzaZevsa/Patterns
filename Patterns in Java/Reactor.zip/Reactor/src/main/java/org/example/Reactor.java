package org.example;
import java.util.HashMap;
import java.util.Map;
public class Reactor {
    private Map<String, EventHandler> eventHandlers = new HashMap<>();
    private SynchronousEventDemultiplexer demultiplexer = new SynchronousEventDemultiplexer();

    public void registerHandler(String eventType, EventHandler handler) {
        eventHandlers.put(eventType, handler);
    }

    public void removeHandler(String eventType) {
        eventHandlers.remove(eventType);
    }

    public void handleEvents(Iterable<Event> events) {
        for (Event e : events) {
            if (eventHandlers.containsKey(e.type)) {
                eventHandlers.get(e.type).HandleEvent(e);
            } else {
                demultiplexer.handle(e);
            }
        }
    }
}
