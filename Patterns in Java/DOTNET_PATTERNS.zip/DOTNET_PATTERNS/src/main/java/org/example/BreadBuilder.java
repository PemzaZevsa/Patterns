package org.example;

public interface BreadBuilder {
    void setName(String name);
    void setSalt(Salt salt);
    void setFlour(Flour flour);
    Bread construct();
}
