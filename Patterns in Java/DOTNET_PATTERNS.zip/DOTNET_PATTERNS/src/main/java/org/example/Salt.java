package org.example;

public class Salt {
    public double amount;

    public Salt(double amount){
        this.amount = amount;
    }
}
