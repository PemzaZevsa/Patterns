package org.example;

public class Director {

    public void makeWhiteBread(BreadBuilder breadBuilder){
        breadBuilder.setName("White Bread");
        Salt salt = new Salt(10.5);
        breadBuilder.setSalt(salt);
        Flour flour = new Flour(430);
        breadBuilder.setFlour(flour);
    }

    public void makeBaguette(BreadBuilder breadBuilder){
        breadBuilder.setName("Baguette");
        Salt salt = new Salt(5.15);
        breadBuilder.setSalt(salt);
        Flour flour = new Flour(390);
        breadBuilder.setFlour(flour);
    }
}
