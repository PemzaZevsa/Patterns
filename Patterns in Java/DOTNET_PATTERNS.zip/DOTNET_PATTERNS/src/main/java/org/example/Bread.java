package org.example;

public class Bread {
    public int id;
    public String name;
    public Salt salt;
    public Flour flour;
    public static int counter;

    public Bread(String name, Salt salt, Flour flour){
        id = counter++;
        this.name = name;
        this.salt = salt;
        this.flour = flour;
    }

    public void toBread(){
        String str = String.format("%s bread. Amount of salt: %f. Amount of salt: %f", name, salt.amount, flour.amount);
        System.out.println(str);
    }
}
