package org.example;

public class ConcreteBreadBuilder implements BreadBuilder{
    public String name;
    public Salt salt;
    public Flour flour;

    public void setName(String name){
        this.name = name;
    }

    public void setSalt(Salt salt){
        this.salt = salt;
    }

    public void setFlour(Flour flour){
        this.flour = flour;
    }

    public Bread construct(){
        return new Bread(name,salt,flour);
    }
}
