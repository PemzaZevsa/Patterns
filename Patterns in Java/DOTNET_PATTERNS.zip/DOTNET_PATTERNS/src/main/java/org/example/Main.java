package org.example;

public class Main {
    public static void main(String[] args) {
        Director director = new Director();
        ConcreteBreadBuilder builder = new ConcreteBreadBuilder();
        director.makeWhiteBread(builder);
        Bread bread1 = builder.construct();
        bread1.toBread();

        director.makeBaguette(builder);
        Bread bread2 = builder.construct();
        bread2.toBread();

        builder.setName("Rye Bread");
        builder.setSalt(new Salt(20.3));
        builder.setFlour(new Flour(490));
        Bread bread3 = builder.construct();
        bread3.toBread();

        System.out.println("Hello world!");
    }
}