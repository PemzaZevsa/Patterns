package org.example;

public class Flour {
    public double amount;

    public Flour(double amount){
        this.amount = amount;
    }
}
