package org.example;

import org.example.Entities.Bank;
import org.example.Entities.Company;
import org.example.Entities.Resident;

public interface Visitor {
    public void visitBank(Bank bank);
    public void visitCompany(Company company);
    public void visitResident(Resident resident);
}
