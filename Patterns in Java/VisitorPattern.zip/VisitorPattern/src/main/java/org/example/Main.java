package org.example;

import org.example.Entities.Bank;
import org.example.Entities.Client;
import org.example.Entities.Company;
import org.example.Entities.Resident;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        Resident resident = new Resident("", "", "", "");
        Company company = new Company("", "", "",20);
        Bank bank = new Bank("", "", "", 3);

        ArrayList<Client> clients = new ArrayList<Client>();
        clients.add(resident);
        clients.add(company);
        clients.add(bank);

        InsuranceMessagingVisitor messaging = new InsuranceMessagingVisitor();
        messaging.sendMessages(clients);

    }
}