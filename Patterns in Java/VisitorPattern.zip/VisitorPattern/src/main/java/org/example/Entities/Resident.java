package org.example.Entities;

import org.example.Visitor;

public class Resident extends Client{
    private final String insurenceClass;
    public Resident(String name, String address, String number, String insurenceClass) {
        super(name, address, number);
        this.insurenceClass = insurenceClass;
    }

    @Override
    public void accept(Visitor visitor) {
        visitor.visitResident(this);
    }
}
