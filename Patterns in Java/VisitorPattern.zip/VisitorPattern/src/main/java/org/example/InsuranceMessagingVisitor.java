package org.example;

import org.example.Entities.Bank;
import org.example.Entities.Client;
import org.example.Entities.Company;
import org.example.Entities.Resident;

import java.util.ArrayList;

public class InsuranceMessagingVisitor implements Visitor{

    public void sendMessages(ArrayList<Client> clients){
        for (var client:
             clients) {
            client.accept(this);
        }
    }
    @Override
    public void visitBank(Bank bank) {
        System.out.println("Sending mail to bank");
    }

    @Override
    public void visitCompany(Company company) {
        System.out.println("Sending mail to company");
    }

    @Override
    public void visitResident(Resident resident) {
        System.out.println("Sending mail to resident");
    }
}
