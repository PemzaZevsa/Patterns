package org.example;

public class Client {
    private Handler handler;

    public Client(Handler handler)
    {
        this.handler = handler;
    }

    public void SendRequest(String request)
    {
        handler.HandleRequest(request);
    }
}
