package org.example;

public class GetComand implements IComand{
    @Override
    public void execute() {
        System.out.println("Выполнение GET запроса");
    }
}
