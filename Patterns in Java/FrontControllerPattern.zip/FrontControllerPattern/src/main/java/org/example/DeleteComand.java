package org.example;

public class DeleteComand implements IComand{
    @Override
    public void execute() {
        System.out.println("Выполнение DELETE запроса");
    }
}
