package org.example;

public class PostComand implements IComand{
    @Override
    public void execute() {
        System.out.println("Выполнение POST запроса");
    }
}
