package org.example;

import java.util.ArrayList;

public class Handler {
    public ArrayList<IComand> comands;
    public Handler(){
        comands = new ArrayList<>();
        comands.add(new GetComand());
        comands.add(new PostComand());
        comands.add(new DeleteComand());
    }

    public void HandleRequest(String request)
    {
        switch (request) {
            case "GET" -> comands.get(0).execute();
            case "POST" -> comands.get(1).execute();
            case "DELETE" -> comands.get(2).execute();
        }
    }
}
