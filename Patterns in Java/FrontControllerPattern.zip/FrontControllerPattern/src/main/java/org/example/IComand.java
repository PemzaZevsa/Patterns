package org.example;

public interface IComand {
    public void execute();
}
