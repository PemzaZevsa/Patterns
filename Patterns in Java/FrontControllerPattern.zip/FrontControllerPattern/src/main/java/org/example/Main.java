package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String str = "";
        var handler = new Handler();
        Client client = new Client(handler);
        Scanner s = new Scanner(System.in);

        while (!str.equals("Exit")){
            str = s.next();

            client.SendRequest(str);
        }
    }
}