﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class PostCommand : ICommand
    {
        public void Execute()
        {
            Debug.WriteLine("Выполнение POST запроса");
        }
    }
}
