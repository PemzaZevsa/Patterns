﻿using System;
using System.Collections.Generic;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            $safeprojectname$ reactor = new $safeprojectname$();

            reactor.RegisterHandler("EventA", new ConcreteEventHandlerA());
            reactor.RegisterHandler("EventB", new ConcreteEventHandlerB());

            var events = new List<Event>
            {
                new Event("EventA"),
                new Event("EventB"),
                new Event("EventC")
            };

            reactor.HandleEvents(events);
        }
    }

}
